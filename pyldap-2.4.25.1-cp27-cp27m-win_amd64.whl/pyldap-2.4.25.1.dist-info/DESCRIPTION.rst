pyldap:
pyldap is a fork of python-ldap, and provides an object-oriented API to access LDAP
directory servers from Python programs. Mainly it wraps the OpenLDAP 2.x libs for that purpose.
Additionally the package contains modules for other LDAP-related stuff
(e.g. processing LDIF, LDAPURLs, LDAPv3 schema, LDAPv3 extended operations
and controls, etc.). 


